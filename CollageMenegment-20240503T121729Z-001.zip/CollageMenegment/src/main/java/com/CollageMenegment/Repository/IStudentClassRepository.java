package com.CollageMenegment.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.CollageMenegment.model.StudentClass;

public interface IStudentClassRepository extends JpaRepository<StudentClass, Long>{
}
