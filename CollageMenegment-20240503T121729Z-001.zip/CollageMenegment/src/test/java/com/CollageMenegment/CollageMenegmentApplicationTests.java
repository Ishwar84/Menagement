package com.CollageMenegment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CollageMenegmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
